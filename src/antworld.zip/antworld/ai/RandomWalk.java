package antworld.ai;

public class RandomWalk
{
  
  public RandomWalk()
  {
    
  }
  public static void main(String[] args)
  {
  }  
}
package antworld.data;

public enum TeamNameEnum
{
  EMPTY,
  NEARLY_BRAINLESS_BOTS, 
  RANDOM_WALKERS,
  AlkaliMuhly,
  Antithesis,
  BlueGrama,
  Bromegrass,
  Buffalograss,
  Canarygrass,
  Daisy,
  Dendrobium,
  GoldenPheasantTail,
  IndianRicegrass,
  Lovegrass,
  MesaDropseed,
  Onion,
  SandDropseed,
  SandLily,
  Seealis,
  SpikeDropseed,
  Thistle,
  Toothachegrass,
  Windmillgrass,
  Wolfcoder,
  Yucca
}
